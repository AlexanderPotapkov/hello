# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['hello', 'hello.scripts']

package_data = \
{'': ['*']}

install_requires = \
['colorama>=0.4.4,<0.5.0']

entry_points = \
{'console_scripts': ['say-hello = hello.scripts.say_hello:main']}

setup_kwargs = {
    'name': 'hello',
    'version': '0.1.0',
    'description': '',
    'long_description': None,
    'author': 'Alexander Potapkov',
    'author_email': 'xanben@mail.ru',
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'entry_points': entry_points,
    'python_requires': '>=3.8,<4.0',
}


setup(**setup_kwargs)
